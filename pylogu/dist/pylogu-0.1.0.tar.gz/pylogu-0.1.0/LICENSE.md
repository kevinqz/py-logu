**Logu Non-Commercial License**

Copyright (c) 2023 Kevin Saltarelli @ Logu

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, subject to the following conditions:

1. **Use and Redistribution**: The Software may be used and redistributed for personal, non-commercial purposes only.

2. **Prohibition of Commercial Use**: The Software, or any derivative works thereof, may not be used for commercial purposes. For the purposes of this license, "commercial purposes" refers to any activity involving the exchange of money or other forms of compensation or any activity intended for or directed toward commercial advantage or monetary compensation.

3. **Modification and Derivative Works**: Users are permitted to modify the Software and to create derivative works from it, provided that such modifications and derivative works are also subject to the terms of this license.

4. **Attribution**: Any use of the Software or derivative works thereof must provide proper attribution to the original author, Kevin Saltarelli @ Logu.

5. **Disclaimer**: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.