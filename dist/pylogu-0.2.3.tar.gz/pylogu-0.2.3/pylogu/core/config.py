class Config:
    LOGU_API_BASE_URL = "https://logu-api.kevinqz.repl.co"

config = Config()